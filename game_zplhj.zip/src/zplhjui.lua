ZPLHJUI = class("ZPLHJUI", SlotsUI)
local SlotRollModel = require("app.gamebase.slotRollModel")
local slotPlayerCellUi = require("app.gamebase.slotPlayerui")
require("game.zplhj.src.zplhjtools")

local SjSize = {
	width = 1334,
	height = 750
}

local AniType ={
	FreeAllEnd = 10001,
	SlotEnd = 10002,
    RollBackEnd = 10003,
}

local CsbPath = 
{
	Fire 	  = "game/zplhj/res/ani/Ani_Fire.csb",
	Puke 	  = "game/zplhj/res/ani/Ani_FP.csb",
	JinBi 	  = "game/zplhj/res/ani/Ani_jinbi.csb",
	IconBox   = "game/zplhj/res/ani/Ani_IconBox.csb",
	IconFree  = "game/zplhj/res/ani/Ani_Free.csb",
	IconWild  = "game/zplhj/res/ani/Ani_Wild.csb",
	IconBonus = "game/zplhj/res/ani/Ani_Bonus.csb",
	RollLight = "game/zplhj/res/ani/Ani_RollLight.csb",
}

local LineAniPath = 
{
	[1] = "game/zplhj/res/lineani/Node_line1.csb",
	[2] = "game/zplhj/res/lineani/Node_line2.csb",
	[3] = "game/zplhj/res/lineani/Node_line3.csb",
	[4] = "game/zplhj/res/lineani/Node_line4.csb",
	[5] = "game/zplhj/res/lineani/Node_line5.csb",
	[6] = "game/zplhj/res/lineani/Node_line6.csb",
	[7] = "game/zplhj/res/lineani/Node_line7.csb",
	[8] = "game/zplhj/res/lineani/Node_line8.csb",
	[9] = "game/zplhj/res/lineani/Node_line9.csb",
}

local Sound = 
{
	BGM_Free 		= "game/zplhj/res/Audio/bgm_free.mp3",
	BGM_Bonus 		= "game/zplhj/res/Audio/bgm_bonus.mp3",
	BGM_Normal 		= "game/zplhj/res/Audio/bgm_normal.mp3",
	BigWin 			= "game/zplhj/res/Audio/bigWin.mp3",
	NorWin 			= "game/zplhj/res/Audio/normalwin.mp3",
	BonusPoker 		= "game/zplhj/res/Audio/bonuspoker.mp3",
	CoinFly 		= "game/zplhj/res/Audio/coins_fly.mp3",
	SpecicalStop 	= "game/zplhj/res/Audio/specialstop.mp3",
	SpecicalWin 	= "game/zplhj/res/Audio/specialwin.mp3",
	SpeedUp 		= "game/zplhj/res/Audio/speedup.mp3",
	Stop 			= "game/zplhj/res/Audio/stop.mp3",
}

function ZPLHJUI:init(mgr)
	ZPLHJUI.super.init(self, mgr)

   
	printToLog("----------------------------------------- 11111111111111111111111111111111111111111111")
	self.resPath = "game/zplhj/res/"
	self.resItemPath = self.resPath
	self.viewRes = self.resPath .. "Layer_main_scn.csb"--LanguageManager.getLanguageRes(self.resPath .. "Layer_main.csb")
	self.layerRuleRes = self.resPath .. "Layer_rule_scn.csb"--LanguageManager.getLanguageRes(self.resPath .. "Layer_rule.csb")

	-- 图标尺寸
	local iconSize = {204, 171}
	self.iconItemSize = {iconSize, iconSize, iconSize, iconSize, iconSize}

	self.isFinish = false
	self.isRunStart = false
	self.isGrayDisAbleBtn = true

	-- 事件注册
	self:registEvent(SlotsGameEvent.event_minGameInit, self.onMsgSMScene, self)
    self:registEvent(SlotsGameEvent.event_minGameStart, self.onMsgSMStart, self)
end

function ZPLHJUI:onAdd(scene, autofix)
	printToLog("self.viewRes ~~~~~~~~~~~~~~~~~~~~~ = " .. self.viewRes)
	ZPLHJUI.super.onAdd(self, scene, autofix)
    self.btnBank:setVisible(false)
    
    local ccbigin_win_panel_4 = ctrl["basePanel_big_reward4"]
end

function ZPLHJUI:addSelfNeedUI(ctrl)
	printToLog("")
	local screeSize = cc.Director:getInstance():getVisibleSize()
	self.layerCustom = ctrl["Panel_custom"]
	self.layerCustom:setScale(screeSize.width/SjSize.width, screeSize.height/SjSize.height)

	local bglayer = ctrl["Panel_bg"]
	bglayer:setVisible(true)
	
	-- 免费时的火焰特效
	self.nodeFreeFire = ctrl["Node_Fire"]
	self.nodeFreeFire:removeAllChildren()

	-- 滚动列高亮
	self.nodeRollLight = {}
	for i = 1, 5, 1 do
		self.nodeRollLight[i] = ctrl["Node_RollLight"..i]
		self.nodeRollLight[i]:removeAllChildren()
	end

	-- 中奖线
	self.nodeLineAni = {}
	for i = 1, 9 , 1 do
		self.nodeLineAni[i] = ctrl["Node_ani_line"..i]
		self.nodeLineAni[i]:removeAllChildren()
	end

	-- 普通中奖，赢的分数
	self.bflblWinScore = NumberBounceNode:create(ctrl["BFLabel_WinScore"], false, true)
	self.bflblWinScore:setNumber(0)
	self.bflblWinScore:setVisible(false)

	-- 小奖
	self.layerSmallReward = ctrl["Panel_small_reward"]
	self.layerSmallReward:setVisible(false)
	self.nodeSmallRewardSpine = ctrl["Node_small_reward_spine"]
	self.nodeSmallRewardSpine:removeAllChildren()
	self.textSmallRewardScore = NumberBounceNode:create(ctrl["Text_small_reward_score"], false, true)
	self.textSmallRewardScore:setNumber(0)

	-- 大奖
	self.layerBigwinReward = ctrl["Panel_bigwin_reward"]
	self.layerBigwinReward:setVisible(false)
	self.aniBigwinReward = ctrl["ArmatureNode_bigwin_reward"]
	self.txtBigwinRewardScore = NumberBounceNode:create(ctrl["Text_bigwin_reward_score"], false, true)
	self.txtBigwinRewardScore:setNumber(0)
	
	-- 玩家分数框高亮
	self.imageUserGoldLight = ctrl["Image_UserGoldLight"]
	self.imageUserGoldLight:setVisible(false)

	-- 免费时的次数提示
	self.ImageFreeTip = ctrl["Image_FreeCount"]
	self.ImageFreeTip:setVisible(false)

	-- 获得免费游戏的提示
	self.nodeGetFreeHit = ctrl["Node_FreeHit"]
	self.nodeGetFreeHit:setVisible(false)
	self.nodeGetFreeHitPos = ZPTools:getNodePos(self.nodeGetFreeHit)
	self.bflblFreeCount = ctrl["BFLabel_Free"]
	self.bflblFreeCount:setString("0")

	---------------------------------------------------------------------------------------------
	-- 金币结算
	self.nodeGoldResult = ctrl["Node_GoldResult"]
	self.nodeGoldResultPos = ZPTools:getNodePos(self.nodeGoldResult)
	self.nodeGoldResult:setVisible(false)
	-- 喷金币特效
	self.nodeJinbi = ctrl["Node_jinbi"]
	self.nodeJinbi:removeAllChildren()
	-- 结算分数
	self.bflblGoldScore = ctrl["BFLabel_GoldResult"]
	self.bflblGoldScore:setString("0")

	---------------------------------------------------------------------------------------------
	-- 小游戏
	self:onAddSmallGameUI(ctrl)

	---------------------------------------------------------------------------------------------
	AudioManager.stopMusic()
	AudioManager.stopAllEffects()
	gAudioManger:resetMusicID(-1) 

	AudioManager.playMusic(Sound.BGM_Normal, true)
end

function ZPLHJUI:initView()
	-- 滚动列高亮
	for i = 1, 5, 1 do
		self.nodeRollLight[i]:removeAllChildren()
	end
	-- 中奖线
	for i = 1, 9 , 1 do
		self.nodeLineAni[i]:removeAllChildren()
	end
	ZPLHJUI.super.initView(self)
end

-------重连回来
function ZPLHJUI:SlotSceneReconnectSuccess()
	-- ui隐藏
	self.bflblWinScore:setVisible(false)
	self.layerSmallReward:setVisible(false)
	self.layerBigwinReward:setVisible(false)
	self.imageUserGoldLight:setVisible(false)
	self.ImageFreeTip:setVisible(false)
	self.nodeGoldResult:setVisible(false)
	self.nodeSmallTip:setVisible(false)
	self.layerSmall:setVisible(false)
	-- 停止动画
	self.bflblWinScore:stopAllActions()
	self.layerSmallReward:stopAllActions()
	self.layerBigwinReward:stopAllActions()

	self:hideRollLight()
	self:addFreeFireAction(false)
	-- 关闭音效
	AudioManager.stopMusic()
	AudioManager.stopAllEffects()
	AudioManager.playMusic(Sound.BGM_Normal, true)
end

-- 显示某一条中奖线
function ZPLHJUI:showRewardLinesAni(i)
	if(self.nodeLineAni[i]) and (not tolua.isnull(self.nodeLineAni[i])) then
		self.nodeLineAni[i]:removeAllChildren()
		ZPTools:addCsbAction(LineAniPath[i], self.nodeLineAni[i], true, nil)
	end
end

-- 隐藏全部中奖线
function ZPLHJUI:hideRewardLinesAni()
	for i = 1, 9, 1 do
		self.nodeLineAni[i]:removeAllChildren()
	end
end

-- 添加火焰特效
function ZPLHJUI:addFreeFireAction(isAdd)
	self.nodeFreeFire:removeAllChildren()
	if(isAdd==true)then
		local fireNode = ZPTools:addCsbAction(CsbPath.Fire, self.nodeFreeFire, true, nil)
		fireNode:setScale(1.4)
	end
end

-- 关闭滚动列高亮
function ZPLHJUI:hideRollLight()
	for i = 1, 5, 1 do
		if(self.nodeRollLight) and (self.nodeRollLight[i]) and (tolua.isnull(self.nodeRollLight[i])==false) then
			self.nodeRollLight[i]:removeAllChildren()
		end
	end
end

-- 显示滚动列高亮
function ZPLHJUI:showRollLight(idx)
	-- 隐藏全部
	self:hideRollLight()
	-- 显示
	if(idx>0) and (idx<=5) and (self.nodeRollLight) and (self.nodeRollLight[idx]) and (tolua.isnull(self.nodeRollLight[idx])==false) then
		-- 加入高亮特效
		ZPTools:addCsbAction(CsbPath.RollLight, self.nodeRollLight[idx], true, nil)
	end
end

-- 关闭特效页面
function ZPLHJUI:closeWinEffectLayer()
	-- 动画标记：已经结束
	self.isFinish = true
	-- 停止动画
	self.bflblWinScore:stopAllActions()
	self.layerSmallReward:stopAllActions()
	self.layerBigwinReward:stopAllActions()
	-- 隐藏
	self.bflblWinScore:setVisible(false)
	self.layerSmallReward:setVisible(false)
	self.layerBigwinReward:setVisible(false)
end

-- 显示玩家分数框高亮图
function ZPLHJUI:showUserGoldLight(count)
	local dtim = 0.25
	local act1 = cc.Show:create()
	local act2 = cc.DelayTime:create(dtim)
	local act3 = cc.Hide:create()
	local act4 = cc.DelayTime:create(dtim)
	local act5 = cc.Sequence:create(act1,act2,act3,act4)
	local time = count or 1
	self.imageUserGoldLight:stopAllActions()
	self.imageUserGoldLight:runAction(cc.Repeat:create(act5, time))
end

-- 显示分数结果(免费结束结算，小游戏结束结算)
function ZPLHJUI:showGoldResult(score, callback, needAni)
	-- 分数
	--self.bflblGoldScore:setString(tostring(score))
	self.bflblGoldScore:setString(string.formatnumberthousands(score))
	-- 初始位置
	local oldPosY = self.nodeGoldResultPos.y+500	

	self.nodeJinbi:removeAllChildren()
	local jinbiNode = ZPTools:addCsbAction(CsbPath.JinBi, self.nodeJinbi, false, nil)
	jinbiNode:setScale(3.5)
	--jinbiNode:setRotation(180)

	local dt = 0
	if(needAni==true) then
		dt = 2
		self.nodeGoldResult:setPosition(cc.p(self.nodeGoldResultPos.x, oldPosY))
	else
		dt = 2.8
		self.nodeGoldResult:setPosition(cc.p(self.nodeGoldResultPos.x, self.nodeGoldResultPos.y))
	end

	-- 动画
	local act0 = cc.Show:create()
	local act1 = cc.MoveTo:create(0.8, cc.p(self.nodeGoldResultPos.x, self.nodeGoldResultPos.y))
	local act2 = cc.DelayTime:create(dt)
	local act3 = cc.Hide:create()
	local act4 = cc.CallFunc:create(function ()
		if(callback) then
			callback()
		end
	end)
	self.nodeGoldResult:stopAllActions()
	
	AudioManager.playEffect(Sound.CoinFly, false)
	if(needAni==true) then		
		self.nodeGoldResult:runAction(cc.Sequence:create(act0, act1, act2, act3, act4))
	else		
		self.nodeGoldResult:runAction(cc.Sequence:create(act0, act2, act3, act4))
	end
end

-- 一轮完成
function ZPLHJUI:onStateReset()
	ZPLHJUI.super.onStateReset(self)
end

-- 开始
function ZPLHJUI:onStateStart()
	self:closeWinEffectLayer()
	local isFree = self.mgr:getIsFree()
	if isFree then
	    AudioManager.playMusic(Sound.BGM_Free, true)
	end
	ZPLHJUI.super.onStateStart(self)
end

-- 游戏开始滚动
function ZPLHJUI:onStateRun()
	-- 显示免费次数面板
	local isFree = self.mgr:getIsFree()
	self.ImageFreeTip:setVisible(isFree)
	self:addFreeFireAction(isFree)
	-- 奖励动画完成标记重置
	self.isFinish = false
	-- 执行父类
	ZPLHJUI.super.onStateRun(self)
end

-- 滚动结束回调
function ZPLHJUI:rollOverCallBack(col, state)
	-- 回弹完成
    print("滚动结束回调 state : " .. state)
	if state == 4 then
		self.rollOverEndCol = self.rollOverEndCol+1
		if self.rollOverEndCol>=#self.itemCou then  
			local seqAni = cc.Sequence:create(cc.DelayTime:create(0.2),cc.CallFunc:create(function()
                print("完成转动")
		        self.mgr:setGameStateOverNext()--完成转动
	        end))
	        seqAni:setTag(AniType.RollBackEnd)
	        self.view:runAction(seqAni)
		end
	-- 滚动结束
	elseif state == 3 then
		self.temRunEndCol = self.temRunEndCol+1
		if(self.temRunEndCol>=#self.itemCou) then
			AudioManager.stopAllEffects()
		end
		-- 滚动列是否高亮
		local nextCol = col+1
		if(self.mgr.speedCol>0)and(self.mgr.speedCol<=nextCol)and(nextCol<=5)then
			-- 音效
			AudioManager.playEffect(Sound.SpeedUp, false)
			-- 特效
			self:showRollLight(nextCol)
		end
		-- 停止音效
		if(self.mgr.SpecialCol[col]>0)then
			AudioManager.playEffect(Sound.SpecicalStop, false)
		else
			AudioManager.playEffect(Sound.Stop, false)
		end
	end
end

-- 奖励阶段
function ZPLHJUI:onStateReward()
	self:hideRollLight()
	ZPLHJUI.super.onStateReward(self)
end

function ZPLHJUI:showRewardLines(lineRes)
	local lines = self.mgr:getResultLine()
    -- dump(lines,"showRewardLines")
	local iconLines = {}
	for k,v in pairs(lines) do
		if v[1] ~= -1 and v[1] ~= 255 then
			-- print("k="..k)
			local line = self.imgLines[k]	
            if self.imgLineNum[k] then		
			    self.imgLineNum[k]:setVisible(true)
            end
            if(line) then
				line:setVisible(true)
				table.insert(iconLines, line)
			end
			self:showRewardLinesAni(k)
		end
	end

	if #iconLines>0 then
        for k,v in pairs(iconLines) do
			v:setVisible(true)
		end
		self.panelLine:setVisible(true)
	end

    self:showRewardLight()
end

-- 亮图标
function ZPLHJUI:showRewardLight()
	local lights = self.mgr:getLightTab()
	local results = self.mgr:getResultTab()
	for i = 1, #self.itemCou, 1 do
		for j = 1, self.itemCou[i], 1 do
			if lights[j][i] == 1 then
				local value = results[j][i]+1
				local posDownEx = self.rollNodeModel[i]._showNumsEx*0.5
                local lightDownUpIdx = self.itemCou[i]-j+posDownEx
				-- 框
				local csbNode, csbAction = ZPTools:createCsbAction(CsbPath.IconBox, true)
				self.rollNodeModel[i]:setAniTypeAndPlay(nil, lightDownUpIdx, 255, csbNode)
				-- Wild
				if(value == self.mgr.WildValue) then
					local csbNode, csbAction = ZPTools:createCsbAction(CsbPath.IconWild, true)
					self.rollNodeModel[i]:setAniTypeAndPlay(nil, lightDownUpIdx, 255, csbNode)
				end
				-- free
				if(value == self.mgr.FreeValue) then
			        local csbNode, csbAction = ZPTools:createCsbAction(CsbPath.IconFree, true)
					self.rollNodeModel[i]:setAniTypeAndPlay(nil, lightDownUpIdx, 255, csbNode)
				end
				-- bonus
				if(value == self.mgr.BonusValue) then
					local csbNode, csbAction = ZPTools:createCsbAction(CsbPath.IconBonus, true)
					self.rollNodeModel[i]:setAniTypeAndPlay(nil, lightDownUpIdx, 255, csbNode)
				end
			end
		end
	end
end

-- 结束播放奖励动画
function ZPLHJUI:endRewardLight()
	-- 执行父类
	ZPLHJUI.super.endRewardLight(self)
	-- 关闭中奖线特效
	self:hideRewardLinesAni()
end

-- 中奖特效
-- function ZPLHJUI:showHitCoinAni()
-- 	local level = self.mgr:getRewardLevel()
-- 	if(level > 0) then
-- 		local score = self.mgr:getWinScore()
-- 		self:showUserGoldLight(2)
-- 		if(level==1) then
-- 			AudioManager.playEffect(Sound.NorWin, false)
-- 			self:showNormalWin(score)			
-- 		elseif(level==2) then
-- 			AudioManager.playEffect(Sound.NorWin, false)
-- 			self:showSuperWinAni(1,score)
-- 		elseif(level==3) then
-- 			AudioManager.playEffect(Sound.BigWin, false)
-- 			--self:showSmallWin(score)
-- 			self:showSuperWinAni(2,score)
-- 		elseif(level==4) then
-- 			AudioManager.playEffect(Sound.BigWin, false)
-- 			--self:showBigWin(score)
-- 			self:showSuperWinAni(3,score)
-- 		-- 超大奖
-- 		elseif(level>=5) then
-- 			--AudioManager.playEffect(Sound.BigWin, false)
-- 			self:showWinGE()
-- 		end		
-- 		-- test
-- 		--self:showSuperWinAni(1,score)
-- 	else
-- 		self:showHitCoinAiEnd()
-- 	end	
-- end

-- 普通赢分动画
function ZPLHJUI:showNormalWin(score)
	-- 分数
	self.bflblWinScore:setNumber(0)
	self.bflblWinScore:bounceToNumber(math.floor(score), 1.0)--:setString(tostring(score))
    self.textSmallRewardScore:setVisible(false)
    self.layerSmallReward:setVisible(false)
	self.layerBigwinReward:setVisible(false)
    self.bflblWinScore:setVisible(true)
	-- 动作
	local act0 = cc.Show:create()
	local act1 = cc.DelayTime:create(2)
	local act2 = cc.Hide:create()
	local act3 = cc.CallFunc:create(function ()
		self:hideSpecialEffects()
		self:showHitCoinAiEnd()
	end)
	self.Panel_exportJson:setVisible(true)
	self.panelReward:setVisible(true)
	self.bflblWinScore:stopAllActions()
	self.bflblWinScore:runAction(cc.Sequence:create(act0,act1,act2,act3))
end

-- 小奖赢分动画
function ZPLHJUI:showSmallWin(score)
	-- 分数
	self.textSmallRewardScore:setNumber(0)
	self.textSmallRewardScore:bounceToNumber(math.floor(score), 1.0)
	-- 特效
	local anims = {"animation", "animation2", "animation3"}
	local armSmallReward = sp.SkeletonAnimation:create("slots/SlotsCommon_win_effect/SlotsCommon_win_effect.json", "slots/SlotsCommon_win_effect/SlotsCommon_win_effect.atlas")
	armSmallReward:setPosition(cc.p(0, 0))
	armSmallReward:setAnimation(0, anims[math.random(1,3)], false)
	self.nodeSmallRewardSpine:removeAllChildren()
	self.nodeSmallRewardSpine:addChild(armSmallReward)
	-- 动作
	local act0 = cc.Show:create()
	local act1 = cc.DelayTime:create(2)
	local act2 = cc.Hide:create()
	local act3 = cc.CallFunc:create(function ()
		self:showHitCoinAiEnd()
	end)
    self.layerSmallReward:setVisible(true)
	self.layerBigwinReward:setVisible(false)
    self.bflblWinScore:setVisible(false)
    
	self.layerSmallReward:stopAllActions()
	self.layerSmallReward:runAction(cc.Sequence:create(act0,act1,act2,act3))
end

-- 大奖赢分动画
function ZPLHJUI:showBigWin(score)
	-- 分数
	self.txtBigwinRewardScore:setNumber(0)
	self.txtBigwinRewardScore:bounceToNumber(math.floor(score), 1.0)
	-- 显示
    self.layerSmallReward:setVisible(false)
	self.layerBigwinReward:setVisible(true)
    self.bflblWinScore:setVisible(false)
	-- 特效    
	self.aniBigwinReward:setVisible(true)
	self.aniBigwinReward:getAnimation():playWithIndex(0)
	self.aniBigwinReward:getAnimation():setMovementEventCallFunc(function (armature, movementType, movementID)
		if movementType == ccs.MovementEventType.complete or movementType == ccs.MovementEventType.loopComplete then
			-- 还未完成 
			if(self.isFinish==false) then
				self.isFinish = true
				self.aniBigwinReward:setVisible(false)
				self.layerBigwinReward:setVisible(false)
				self:showHitCoinAiEnd()
			end
		end
	end)
end

function ZPLHJUI:showSuperWinAni(idx, score)
	----不存在
	if not self.bigin_win_panel_3 or not self.baseArmature_big_reward3 then
		return
	end	
	self.Panel_exportJson:setVisible(true)
	self.panelReward:setVisible(true)
	self.bigin_win_panel_3:setVisible(true)
        
	if self.audioWin and self.audioWin[4] then
		AudioManager.playEffect(self.audioWin[4])
	end
	self.baseText_big_score3:setNumber(0)
	self.baseText_big_score3:bounceToNumber(self.mgr:getWinScore(), 2.5)	
	
	self.baseArmature_big_reward3:setVisible(true)
	self.baseArmature_big_reward3:getAnimation():play("dajiang_"..idx)
	self.baseArmature_big_reward3:getAnimation():setMovementEventCallFunc(function (armature, movementType, movementID)
		if movementType == ccs.MovementEventType.complete then
			-- self.bigin_win_panel_3:setVisible(false)
			-- self.baseArmature_big_reward3:stopAllActions()
			-- self:hideSpecialEffects()
			-- self:showHitCoinAiEnd()
		end
	end)
	self.bigin_win_panel_3:stopAllActions()
	self.bigin_win_panel_3:runAction(cc.Sequence:create(cc.DelayTime:create(3.1), cc.CallFunc:create(function ()
		self.bigin_win_panel_3:setVisible(false)
		self.baseArmature_big_reward3:stopAllActions()
		self:hideSpecialEffects()
		self:showHitCoinAiEnd()
	end)))
end

-- 中免费次数
function ZPLHJUI:showHitFreeAni()
	-- 免费次数
	local count = self.mgr:getCurFree()
	self.bflblFreeCount:setString(tostring(count))
	self.bflblFreeCount:setColor(cc.c3b(255,214,33))
	-- 坐标
	local oldPosY = self.nodeGetFreeHitPos.y+500
	self.nodeGetFreeHit:setPosition(cc.p(self.nodeGetFreeHitPos.x, oldPosY))

	-- 动画
	local act0 = cc.Show:create()
	local act1 = cc.MoveTo:create(0.8, cc.p(self.nodeGetFreeHitPos.x, self.nodeGetFreeHitPos.y))
	local act2 = cc.DelayTime:create(1)
	local act3 = cc.Hide:create()
	local act4 = cc.CallFunc:create(function ()
		-- 免费背景音乐
		AudioManager.playMusic(Sound.BGM_Free, true)
		-- 火焰特效
		self:addFreeFireAction(true)
		-- 执行下一步
		self.showRewardState.showFreeOver = 2
    	self:showSpecialAniNext()
	end)
	self.nodeGetFreeHit:stopAllActions()
	self.nodeGetFreeHit:runAction(cc.Sequence:create(act0, act1, act2, act3, act4))
end

-- 中免费结束结算
function ZPLHJUI:showFreeAllTimesEnd()
	-- 回调
	local freeResultCallback = function ()		
		AudioManager.playMusic(Sound.BGM_Normal, true)
		-- 免费次数面板关闭
		self.ImageFreeTip:setVisible(false)
		self:addFreeFireAction(false)
		-- 进入下一阶段
		self.mgr:setIsFree(false)
		self.mgr:setGameStateOverNext()--完成奖励特效
	end
	local count, score = self.mgr:getTotalFree()
	self:showGoldResult(score, freeResultCallback)
end

-------------------------------------------------------------------------------------------------
-- 小游戏UI
function ZPLHJUI:onAddSmallGameUI(ctrl)
	-- 小游戏提示
	self.nodeSmallTip = ctrl["Node_SmallTip"]
	self.nodeSmallTipPos = ZPTools:getNodePos(self.nodeSmallTip)
	self.nodeSmallTip:setVisible(false)

	-- 小游戏UI
	self.layerSmall = ctrl["Panel_small"]
	self.layerSmall:setVisible(false)
	-- 纸牌按钮
	self.btnPuke = {}
	self.btnPukePos = {}
	for i = 1, 5, 1 do
		self.btnPuke[i] = ctrl["Button_Puke"..i]
		self.btnPuke[i]:onTouch(function (event)
			if(event.name == "ended") then
				self:PukeSelectEvent(i)
			end
		end)
		local btnPukeChild = self.btnPuke[i]:getChildByName("btn_puke")
		btnPukeChild:onTouch(function (event)
			if(event.name == "ended") then
				self:PukeSelectEvent(i)
			end
		end)
		self.btnPukePos[i] = ZPTools:getNodePos(self.btnPuke[i])
	end
	-- 选后的纸牌
	self.ImageSelecetPuke = ctrl["Image_RunHst"]
	self.ImageSelecetPukePos = ZPTools:getNodePos(self.ImageSelecetPuke)
	self.ImageSelecetPuke:setVisible(false)
	-- 小游戏赢分特效
	self.nodeSmallWin = ctrl["Node_SmallWin"]
	self.nodeSmallWin:removeAllChildren()
end

-- 显示小游戏提示动画
function ZPLHJUI:showSmallTipAni()
	-- 坐标
	local oldPosY = self.nodeSmallTipPos.y+500
	self.nodeSmallTip:setPosition(cc.p(self.nodeSmallTipPos.x, oldPosY))

	-- 动画
	local act0 = cc.Show:create()
	local act1 = cc.MoveTo:create(0.8, cc.p(self.nodeSmallTipPos.x, self.nodeSmallTipPos.y))
	local act2 = cc.DelayTime:create(1)
	local act3 = cc.Hide:create()
	local act4 = cc.CallFunc:create(function ()
		-- 执行下一步
		self:showSmallLayer()
	end)
	self.nodeSmallTip:stopAllActions()
	self.nodeSmallTip:runAction(cc.Sequence:create(act0, act1, act2, act3, act4))
end

-- 显示小游戏界面
function ZPLHJUI:showSmallLayer()
	-- 音效
	AudioManager.stopMusic()
	AudioManager.stopAllEffects()
	AudioManager.playMusic(Sound.BGM_Bonus, true)

	local dt=0.15
	for i = 2,5,1 do
		self.btnPuke[i]:stopAllActions()
		self.btnPuke[i]:runAction(cc.MoveTo:create(dt*(i-1), self.btnPukePos[i]))
	end
	self.layerSmall:setVisible(true)
end

-- 关闭小游戏
function ZPLHJUI:closeSmallLayer()
	AudioManager.stopMusic()	
	AudioManager.stopAllEffects()
	if(self.mgr:getIsFree()) then
		AudioManager.playMusic(Sound.BGM_Free, true)
	else
		AudioManager.playMusic(Sound.BGM_Normal, true)
	end
	self.layerSmall:setVisible(false)
end

-- 小游戏结束
function ZPLHJUI:smallGameFinish(score)
	local smallFinishCallback = function ()
		self.mgr:setGameStateOverNext()
	end
	self:closeSmallLayer()
	self:showGoldResult(score, smallFinishCallback)
end

-- 小游戏选牌
function ZPLHJUI:PukeSelectEvent(idx)
	self.mgr:sendSgStart(idx)
end

-- 发送小游戏进入消息
function ZPLHJUI:onStateMGame(args)
	ZPLHJUI.super.onStateMGame(self, args)
	self.mgr:sendSgSceneInfo()
end

-- 小游戏场景消息
function ZPLHJUI:onMsgSMScene(msg)
	-- 初始设置
	for i = 1, 5, 1 do
		self.btnPuke[i]:setPosition(cc.p(self.btnPukePos[1]))
		self.btnPuke[i]:setVisible(true)
	end
	self.ImageSelecetPuke:setVisible(false)
	-- 小游戏开场动画
	self:showSmallTipAni()
end

-- 小游戏拉取结果
function ZPLHJUI:onMsgSMStart(msg)
	local idx = msg.result or 1
	local score = msg.TotalWinScore or 0
	self.btnPuke[idx]:setVisible(false)
	self.ImageSelecetPuke:setPosition(cc.p(self.btnPukePos[idx]))
	self.ImageSelecetPuke:stopAllActions()
	self.ImageSelecetPuke:runAction(cc.Sequence:create(cc.Show:create(), cc.MoveTo:create(0.2, cc.p(self.ImageSelecetPukePos)), cc.Hide:create(), cc.CallFunc:create(function ()
		self.nodeSmallWin:removeAllChildren()
		local csbNode = ZPTools:addCsbAction(CsbPath.Puke, self.nodeSmallWin, false, nil)
		local txtWinScore = csbNode:getChildByName("SmallWinScore")
		txtWinScore:setString(tostring(score))

		-- 音效
		AudioManager.playEffect(Sound.BonusPoker, false)

		self.nodeSmallWin:stopAllActions()
		self.nodeSmallWin:runAction(cc.Sequence:create(cc.DelayTime:create(2), cc.CallFunc:create(function ()
			self.nodeSmallWin:removeAllChildren()
			self:smallGameFinish(score)
		end)))
	end)))
end

---------------------------------------------------------------------------------------------------
-- 设置启动按钮状态
--设置启动按钮状态
function ZPLHJUI:changeRollBtnState()
    self:hideStartBtn(true) 
    local state = self.mgr:getStatus()
    local bAuto  =self.mgr:getIsAuto()
    local isFree = self.mgr:nextIsFree()
    print("11changeRollBtnState==",state,bAuto,isFree)
    if state == SlotsGameStatus.status_init then
        self:hideStartBtn(true)
    elseif state == SlotsGameStatus.status_reset then--空闲 -- or state == SlotsGameStatus.status_reward -- 只有空闲才能点击下注，加减线操作
        self:hideStartBtn(true,true)
        local bShowStartBtn = false
        if isFree==true then--免费中
            self.btnStart:setVisible(true)
            self:setButtonEnable(self.btnStart,true)
            self:setTongBtnState(false)	
        elseif bAuto==true then--自动
            self.btnCancelAuto:setVisible(true)
            self:setButtonEnable(self.btnCancelAuto,true)   
            self:setTongBtnState(false)	
            if self.isLongStartAuto==false then
                bShowStartBtn = true
            end
        else
            bShowStartBtn = true
        end
        if bShowStartBtn==true then
            if self.isLongStartAuto==false and self.btnAuto and bAuto==false then
                self.btnAuto:setVisible(true)
                self:setButtonEnable(self.btnAuto,true)   
            end
            self.btnStart:setVisible(true)
            if self.mgr:isStartAbleState()==true then
                self:setButtonEnable(self.btnStart,true)   
            end
            self:setTongBtnState(true)	
        end
	elseif state == SlotsGameStatus.status_start then--发送滚动
        self:setTongBtnState(false)
        self:setButtonEnable(self.btnStart,false)  
		if self.isLongStartAuto==false and self.btnAuto then
            self:setButtonEnable(self.btnAuto,false)  
		end
    elseif state == SlotsGameStatus.status_run then--滚动中
        self:hideStartBtn(true,true)
        if self.mgr:getIsFree()==true then--免费中            
            if self.btnStopFree then
                self.btnStopFree:setVisible(true)
                self:setButtonEnable(self.btnStopFree,true)          
            else
            	if not self.mgr:getIsFree() then
	                self.btnStop:setVisible(true)
                    self:setButtonEnable(self.btnStop,self.canStopRoll)  
	            else
		            self.btnStart:setVisible(true)
                    self:setButtonEnable(self.btnStart,false)  
	            end
            end
        elseif bAuto==true then--自动
            self.btnCancelAuto:setVisible(true)
            self:setButtonEnable(self.btnCancelAuto,true)  
        else
            if self.btnAuto then
                self.btnAuto:setVisible(true)
                self:setButtonEnable(self.btnAuto,true)  
            end
            if not self.mgr:getIsFree() then
	            self.btnStop:setVisible(true)
                self:setButtonEnable(self.btnStop,self.canStopRoll)  
	        else
	        	self.btnStart:setVisible(true)
                self:setButtonEnable(self.btnStart,false)  
	        end
        end
        self:setTongBtnState(false)
    elseif state == SlotsGameStatus.status_reward or state == SlotsGameStatus.status_slotend then--播奖励
        if self.mgr:getSmallGameFlag() == 0 then--不进小游戏
            self:hideStartBtn(true,true)
            if isFree==false and bAuto==false then--非免费中\非自动中
                self.btnStart:setVisible(true)
                if self.mgr:isStartAbleState()==true then
                    self:setButtonEnable(self.btnStart,true)  
                end
                self:setTongBtnState(true)	
            elseif isFree==true then
                if not self.mgr:getIsFree() then
	                self.btnStop:setVisible(true)
                    self:setButtonEnable(self.btnStop,false)  
	            else
	        	    self.btnStart:setVisible(true)
                    self:setButtonEnable(self.btnStart,false)  
	            end
            elseif bAuto==true then    
                self.btnCancelAuto:setVisible(true)
                self:setButtonEnable(self.btnCancelAuto,false)  
            end
        end
    else
        self:setTongBtnState(false)
    end	
end

function ZPLHJUI:startCallBack(event)
	local status = self.mgr:getStatus()
	printToLog("SlotsUI:startCallBack", status)
	if event.name == "began" then
		if self.mgr:isStartAbleState()==false then--不能开始
			return false
		end     
		self.isRunStart=false   
        self.touchStartTimeBegin = os.time()
        self:aniRunAuto(true)
	elseif event.name == "ended" then   
		self:aniRunAuto(false)
		
		if(self.isRunStart==false) then
	        if self.mgr:sendStart() then
                self:setButtonEnable(event.target,false) 
	        end
	    end
	    self.isRunStart=false
	elseif event.name == "cancelled" then
		self:aniRunAuto(false)
		if self.mgr:getIsAuto() and (self.isRunStart==false) then
			if self.mgr:sendStart() then
                self:setButtonEnable(event.target,false) 
			end
		end
		self.isRunStart=false
	end
end

function ZPLHJUI:aniRunAuto(bRun)
    if self.isLongStartAuto==true then
        if bRun then
            self.autoAniHandle = GlobalFun.performWithDelayGlobal(function()
			    if self.audioBtnLong then
				    self.audioLongId = AudioManager.playEffect(self.audioBtnLong)
			    end
			    self.isRunStart = true
			    self.mgr:setAutoCou(5)
			    self.mgr:doAuto(false)
            end, 1.5)
        else
            if self.audioLongId then
			    AudioManager.stopEffect(self.audioLongId)
			    self.audioLongId = nil
		    end
            if self.autoAniHandle then
                local scheduler = cc.Director:getInstance():getScheduler()
		        scheduler:unscheduleScriptEntry(self.autoAniHandle)
		        self.autoAniHandle = nil
            end
            self:changeRollBtnState()
        end
    end
end


function ZPLHJUI:stopRewardCallBack(event)
	if event.name == "ended" then
		AudioManager.stopAllEffects()
	end
	ZPLHJUI.super.stopRewardCallBack(self, event)
end

-- 显示规则
function ZPLHJUI:showRuleUi(needChange, width, height)
	-- 资源存在
	if self.layerRuleRes~="" then
		local maskRoot,ctrl = GlobalFun.createUI(self.layerRuleRes, false)
	    self.view:addChild(maskRoot)

	    local bgLayer = ctrl["Panel_4"]
	    bgLayer:setScaleX(1.1)

	    local btnClose = ctrl["Button_close"]
	    btnClose:onTouch(function (event)
	    	if(event.name == "ended") then
	    		maskRoot:removeFromParent()
	    	end
	    end)

	    local pageView = ctrl["RulePageView"]
	    	
	    local btnPageIdx = {}
	    -- 第二页
	    btnPageIdx[1] = ctrl["Image_pageidx1"]
	    btnPageIdx[4] = ctrl["Image_pageidx2_0"]
	    -- 第一页
	    btnPageIdx[2] = ctrl["Image_pageidx2"]
	    btnPageIdx[3] = ctrl["Image_pageidx1_0"]

	    local curPageIdx = 1
	    local btnPro = ctrl["Button_pro"]
	    local btnNext = ctrl["Button_next"]
	    btnPro:setScale(1.2)
	    btnNext:setScale(1.2)

	    local changePage = function (pageidx)
	    	btnPageIdx[2]:setVisible(pageidx==1)
	    	btnPageIdx[3]:setVisible(pageidx==1)
	    	btnPageIdx[1]:setVisible(pageidx~=1)
	    	btnPageIdx[4]:setVisible(pageidx~=1)
	    	--btnPro:setVisible(pageidx~=1)
	    	--btnNext:setVisible(pageidx~=2)
	    end

	    btnPro:onTouch(function (event)
	    	if(event.name == "ended") then
	    		curPageIdx=curPageIdx-1
	    		if(curPageIdx<1) then curPageIdx = 1 end
	    		pageView:setCurrentPageIndex(curPageIdx-1)
	    		changePage(curPageIdx)
	    	end
	    end)

	    btnNext:onTouch(function (event)
	    	if(event.name == "ended") then
	    		curPageIdx=curPageIdx+1
	    		if(curPageIdx>2) then curPageIdx = 2 end
	    		pageView:setCurrentPageIndex(curPageIdx-1)
	    		changePage(curPageIdx)
	    	end
	    end)

	    pageView:onEvent(function (event)
	    	if(event.name == "TURNING") then
	    		printToLog("-----------------------------------------")
	    		printToLog("sender type = " .. type(event.target))
	    		dump(event.target, "sender")
	    		dump(event, "vent")
	    		local pageidx = pageView:getCurrentPageIndex()
	    		printToLog("pageidx = " .. pageidx)
	    		curPageIdx = pageidx+1
	    		changePage(curPageIdx)
	    	end
	    end)

	    changePage(curPageIdx)
	end
end