ZPLHJMsg = class("ZPLHJMsg", SlotsMsgBase)

local gameID = 3022
local rowCou = 3    -- 行
local colCou = 5    -- 列

function ZPLHJMsg:ctor()
    printToLog("ZPLHJMsg:ctor")
    local zplhjmgr = GlobalFun.reload("game.zplhj.src.zplhjmgr")
    self.gameMgr = zplhjmgr.new()
end

--初始化游戏数据
function ZPLHJMsg:initGame()
    -- 返回 游戏ID，游戏人数，游戏版本
    return gameID, 1, Devinfo.getGameVersion(6,0,3)
end

--游戏数据准备完成，开始表现游戏界面
function ZPLHJMsg:showGameUI(scene)
    -- to do 开始表现游戏界面
    scene:showUI(eUI.UI_ZPLHJ, self.gameMgr)
end

-- 链接成功
function ZPLHJMsg:reconnectSuccess()
    local data = {
        cbAllowLookon = false,
        dwFrameVersion = Devinfo.getPlazaVersion(),
        dwClientVersion = Devinfo.getGameVersion(6,0,3)
    }
    NetManager.sendMsgToServer_Game(Cmd.CmdGameOption, data)
    ---初始化玩家(自己不传到playerPanel)
    local list = UsersMgr:getGameUserList()
    if #list > 0 then
        for k,v in pairs(list) do            
            if v.wTableID == UsersMgr.getMyTable() then
                self.gameMgr:onUserEnter(v)
            end
        end
    end
end

--游戏退出
function ZPLHJMsg:exitGame()
    -- to do 关闭游戏处理
    EventManager.sendEvent(EVT.QHSLClose)
end

--游戏掉线
function ZPLHJMsg:onOffline()                               
    --to do 断线重连
end

-- 场景消息
function ZPLHJMsg:onGameScene(status, package)
    print("纸牌老虎机-场景消息")
    local msg = NetManager.getServerData(package, "GameSceneInfo")
    self.gameMgr:onMsgScene(msg)
end

-- 游戏内消息处理
function ZPLHJMsg:onGameMessage(mCmd,sCmd,package)
	if mCmd == 200 then
		-- 拉取结果
		if sCmd == 100 then
			local msg = NetManager.getServerData(package, "GameEnd")
			self.gameMgr:onMsgStart(msg)
		-- 小游戏场景消息
		elseif sCmd == 500 then
            local msg = NetManager.getServerData(package, "BonusGameSceneInfo")
            self.gameMgr:onMsgSgScene(msg)
		-- 小游戏结果
		elseif sCmd == 5 then
            local msg = NetManager.getServerData(package, "BonusGameEnd")
            self.gameMgr:onMsgSgStart(msg)
		end
	end
end

ServerGameMgr.setCurMsgHandler(ZPLHJMsg.new())