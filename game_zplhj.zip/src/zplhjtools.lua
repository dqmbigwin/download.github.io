ZPTools = ZPTools or {}

-- 得到坐标
function ZPTools:getNodePos(_node)
	if(_node) and (tolua.isnull(_node)==false) then
		local x1, y1 = _node:getPosition()
		return {x=x1, y=y1}
	end
	return {x=0, y=0}
end

-- 添加序列帧动画
function ZPTools:addCsbAction(csbPath, uiNode, isLoop, callback)
	-- 父控件为空
	if(uiNode==nil) or (tolua.isnull(uiNode)==true) then
		return
	end
	-- 资源路径不存在
	if(csbPath==nil)or(type(csbPath)~="string")or(csbPath=="") then
		return
	end

	local csbAction = cc.CSLoader:createTimeline(csbPath)
	csbAction:gotoFrameAndPlay(0, isLoop)

	local csbNode = cc.CSLoader:createNode(csbPath)
	csbNode:runAction(csbAction)
	csbNode:addTo(uiNode)

	-- if(isLoop==false) then
	-- 	csbAction:setLastFrameCallFunc(function ()
	-- 		csbNode:removeFromParent()
	-- 		if(callback) then
	-- 			callback()
	-- 		end
	-- 	end)
	-- end

	return csbNode, csbAction
end

-- 创建动画
function ZPTools:createCsbAction(csbPath, isLoop)
	local playNode = cc.CSLoader:createNode(csbPath)
	local action = cc.CSLoader:createTimeline(csbPath)
	playNode:runAction(action)
	action:gotoFrameAndPlay(0, isLoop)
	return playNode, action
end

function ZPTools:SeekNodeByName(root, name)
    if nil == root then
        return nil
    end
    if root:getName() == name then
        return root
    end
    local children = root:getChildren()
    for k, v in pairs(children) do
        if nil ~= v then
            res = self:SeekNodeByName(v, name)
            if nil ~= res then
                return res
            end
        end
    end
    return nil
end

function ZPTools:createParticleEffect(effectFile,particleNodeName,particleTextures,duration,bFreePos,bActionUI, CallFucnCallback,nScale)
    local playNode
    if bActionUI then
        playNode=self:createEffect(effectFile,true)
    else
        playNode=cc.CSLoader:createNode(effectFile)
    end
    if playNode == nil then
        printToLog("粒子playNode创建失败！————————————————————")
        return nil
    end
    return self:setParticleEffect(playNode,particleNodeName,particleTextures,duration,bFreePos,CallFucnCallback,nScale)
end

function ZPTools:createEffect(effectFile, bLoop, startIndex, endIndex, lastFrameBack)
    local playNode = cc.CSLoader:createNode(effectFile)
    if playNode == nil then
        printToLog("特效粒子nil_______________________")
        return nil
    end
    local action = cc.CSLoader:createTimeline(effectFile)
    if action then
       local isNode = tolua.iskindof(playNode, "cc.Node")
       if not isNode then  playNode = cc.CSLoader:createNode(effectFile) end
       playNode:runAction(action)
    end
    --
    if startIndex == nil then
        startIndex = 0
    end
    if bLoop == nil then
        bLoop = false
    end
    if endIndex == nil then
        action:gotoFrameAndPlay(startIndex, bLoop)
    else
        action:gotoFrameAndPlay(startIndex, endIndex, bLoop)
    end
    if lastFrameBack then
        action:setLastFrameCallFunc(lastFrameBack)
    end
    return playNode, action
end

function ZPTools:setParticleEffect(playNode,particleNodeName,particleTextures,duration,bFreePos,CallFucnCallback)
    local playParticle = self:SeekNodeByName(playNode,particleNodeName)
    if playParticle == nil then
        return nil
    end
    if bFreePos then
        playParticle:setPositionType(cc.POSITION_TYPE_FREE)
    end
    if particleTextures then
        local imgIndex=0
        local function setTexture2()
            imgIndex=imgIndex+1
            if particleTextures[imgIndex]==nil then
                imgIndex=1
            end
            local coin_texture = cc.Director:getInstance():getTextureCache():addImage(particleTextures[imgIndex])
            if coin_texture then
                playParticle:setTexture(coin_texture)
            end
        end
        setTexture2()
        local action=cc.RepeatForever:create(cc.Sequence:create(cc.DelayTime:create(duration),cc.CallFunc:create(setTexture2)))
        playParticle:runAction(action)
    end
    if CallFucnCallback ~= nil and playParticle:getDuration() > 0 then
        local passTime=playParticle:getDuration()+playParticle:getLife()
        playParticle:runAction(cc.Sequence:create(cc.DelayTime:create(passTime),cc.CallFunc:create(CallFucnCallback)))
    end
    return playNode,playParticle
end