local slotsmgr = require("app.gamebase.slotsmgr")
local ZPLHJMgr = class("ZPLHJMgr", slotsmgr)

local rowCou = 3
local colCou = 5

local gameId = 3190

-- 初始化
function ZPLHJMgr:init()
	ZPLHJMgr.super.init(self)

    self.WildValue = 9
    self.FreeValue = 11
    self.BonusValue = 10
    self.speedCol = 0
    self.SpecialCol = {0,0,0,0,0}
     self._superGE = 1     ---是否有第4个中奖特效，0：没有，1：有，默认没有
     self._bigWin_type = 3
    self.runFirstListTime = 0.9 --第一列运行时间
    self.returnBackTime = 0.1 --回弹的时间
    self.returnBackDesNum = 0.15--回弹的距离
    for i=1,#self._itemCou do
        self._runRandItem[i] = 16+(i-1)*6
        self._runRollAllItemNums[i] = self._showOnePageNums[i]+self._runRandItem[i]
    end
end

-- 关闭游戏
function ZPLHJMgr:closeGame()
	__debug = false
	ZPLHJMgr.super.closeGame(self)
end

--修改奖励等级
function ZPLHJMgr:changeRewardLevel(args)
    self.rewardLevel = SlotsRewardLevel.level_0
    if self.winScore > 0 then
        local rewardTime = self.winScore/self.betGold
        if rewardTime < 4 then
            self.rewardLevel = SlotsRewardLevel.level_1
        elseif rewardTime>=4 and rewardTime<6 then
            self.rewardLevel = SlotsRewardLevel.level_2
        elseif rewardTime>=6 and rewardTime<10 then
            self.rewardLevel = SlotsRewardLevel.level_3
        elseif rewardTime>=10 and rewardTime<15 then
            self.rewardLevel = SlotsRewardLevel.level_4
        elseif rewardTime>15 then
            self.rewardLevel = SlotsRewardLevel.level_5
        end
    end
end

-- 发送拉取消息
function ZPLHJMgr:onSendStart(bet, betLine)
	local msg = 
	{
		LineNum = betLine,
		SingleBet = bet
	}
	NetManager.sendMsgToServer_GameEx(200, 1, msg, "GamePull")
end

-- 发送小游戏场景消息
function ZPLHJMgr:sendSgSceneInfo()
    printToLog("_______________________ 发送小游戏场景消息:")
    NetManager.sendMsgToServer_GameEx(200, 4)
end

-- 发送小游戏选择消息
function ZPLHJMgr:sendSgStart(idx)
    printToLog("_______________________ 发送小游戏选择消息:")
    local msg =
    {
        index = idx
    }
    NetManager.sendMsgToServer_GameEx(200, 5, msg ,"BounsGameGuess")
end

-- 重置滚动数据（ispeed,是否加速, col,第几列）
function ZPLHJMgr:resetRollData(isSpeed, col)
    local defCell = 12
    local addCell = 8
    local spdCell = 12
    if(isSpeed==false) then
        for i=1,#self._itemCou do
            self._runRandItem[i] = defCell+(i-1)*addCell
            self._runRollAllItemNums[i] = self._showOnePageNums[i]+self._runRandItem[i]
        end
    else
        for i=1,#self._itemCou do
            if(i<col) then
                self._runRandItem[i] = defCell+(i-1)*addCell
            else
                self._runRandItem[i] = defCell+(i-1)*spdCell
            end
            self._runRollAllItemNums[i] = self._showOnePageNums[i]+self._runRandItem[i]
        end
    end
end

-- 修改滚动的数据(resultTab是服务器数据，重0开始)
function ZPLHJMgr:changeRollData(resultTab)--行列转换
    --把一页的数量拷贝到最前面去
    local resultData = {}
    local row = #resultTab
    local line = #resultTab[1]
    for i=1,line do
        resultData[i] = {}
        for j=1,row do
            resultData[i][j] = resultTab[j][i]
        end
    end

    self:resetRollData(self.speedCol>0, self.speedCol)

    self._dataRollItems = self._lastPageIcons
    for i=1,#self._itemCou do
        for j=1,self._runRandItem[i] do
            local itemId = math.random(1,self._iconMaxNums)
            table.insert(self._dataRollItems[i],itemId)
        end
    end
    self:pushEndIcons(resultData)
    --把最后的放到最后
    for i=1,#self._itemCou do
        local nums = #self._lastPageIcons[i]
        for j=1,nums do
            table.insert(self._dataRollItems[i],self._lastPageIcons[i][j])
        end
    end
end

-- 场景消息
function ZPLHJMgr:onMsgScene(msg)
	local myScore       	= msg.MyScoreInfo         	-- 我的分数
    local singleUnit    	= msg.SingleUnit        	-- 单注分数列表
    local maxBet        	= msg.SingleMaxBet         	-- 最大下注
    local addLine       	= msg.AddLine           	-- 加减的间隔线数量
    local totalLine     	= msg.TotalLine         	-- 总线数量
    local freeTime      	= msg.FreePullTime      	-- 免费剩余次数
    local pullSingleBet 	= msg.pullSingleBet     	-- 免费时单注
    local pullLineNum   	= msg.pullLineNum         	-- 免费时线数
    local bounsPullTime 	= msg.BounsPullTime     	-- bonus小游戏次数
    local goldPool      	= msg.GoldPool             	-- 奖金池
    local freeWinScore  	= msg.FreeWinScore      	-- 免费赢的分数
    local totalFreeTime 	= msg.TotalFreeTime     	-- 总免费次数
    -- 调父类
	ZPLHJMgr.super.onMsgScene(self,myScore, singleUnit, maxBet, addLine, totalLine, freeTime, 
		pullSingleBet, pullLineNum, bounsPullTime, goldPool, freeWinScore, totalFreeTime)
end

-- 拉取消息
function ZPLHJMgr:onMsgStart(msg)
    printToLog("拉取消息拉取消息拉取消息拉取消息拉取消息拉取消息")
	local resultTab         = self:analyTab(msg.m_Table)
    local lightTab          = self:analyTab(msg.m_TableLine)
    local aline             = msg.Line
    local userScore         = msg.userScore             	-- 玩家分数
    local winScore          = msg.WinScore              	-- 赢的分数
    local freePullTime      = msg.FreePullTime     	        -- 剩余免费次数
    local getFreePullTime   = msg.GetFreePullTime       	-- 获得的免费次数
    local goldPoolPrize     = msg.GoldPoolPrize             -- 奖池中奖
    local goldPool_Current  = msg.GoldPool_Current          -- 当前奖池
    local totalFreeTime     = msg.TotalFreeTime         	-- 总的免费次数
    local freeWinScore      = msg.FreeWinScore          	-- 免费次数赢的分
    local scatterNum        = 0            	                -- 免费转图标个数
    local isSgFalg          = msg.m_iSmallGameStartFlag>0 	-- //小游戏开始标志  0-没有  1-开始

    -- 检测是否有加速列
    self.speedCol = self:checkSpeedCol(resultTab)
    print("------------------------------------- self.speedCol = " .. self.speedCol)
    -- 检测每列是否有特殊图标(wild,free,bonus)
    self.SpecialCol = self:checkSpecialCol(resultTab)

    -- 调父类
	ZPLHJMgr.super.onMsgStart(self, resultTab, aline, lightTab, userScore, winScore, isSgFalg, freePullTime, 
		getFreePullTime, scatterNum, goldPoolPrize, goldPool_Current, totalFreeTime, freeWinScore)
end

-- 小游戏场景消息
function ZPLHJMgr:onMsgSgScene(msg)
    EventManager.sendEvent(SlotsGameEvent.event_minGameInit, msg)
end

-- 小游戏结果消息
function ZPLHJMgr:onMsgSgStart(msg)    
    dump(msg, "小游戏结果消息")
    EventManager.sendEvent(SlotsGameEvent.event_minGameStart, msg)
end

-- 服务器数据转换
function ZPLHJMgr:analyTab(tab)
    local tmp = {}
    for i = 1, rowCou, 1 do
        tmp[i] = {}
        for j = 1, colCou, 1 do
            local k = (i-1)*colCou+j
            tmp[i][j] = tab[k]
        end
    end
    return tmp
end

-- 判断某列是否需要加速
function ZPLHJMgr:checkSpeedCol(tab)
    if(type(tab)~="table") or (tab=={}) then
        return 0
    end

    local col = 0
    local num = 0
    for i = 1, colCou, 1 do -- 列
        for j = 1, rowCou, 1 do -- 行
            local v = tab[j][i]+1
            if(v==self.FreeValue) then -- 免费图标
                num=num+1
                if(i>col) then
                    col=i
                end
                break
            end
        end
        if(num==2) then
            break
        end
    end
    if(num>=2)and(col>0)and(col<5)then
        return col+1
    end
    -- 重置
    col = 0
    num = 0
    for i = 1, colCou, 1 do -- 列
        for j = 1, rowCou, 1 do -- 行
            local v = tab[j][i]+1
            if(v==self.BonusValue) then -- Bonus图标
                num=num+1
                if(i>col) then
                    col=i
                end
                break
            end
        end
        if(num==2) then
            break
        end
    end
    if(num>=2)and(col>0)and(col<5)then
        return col+1
    end
    return 0
end

-- 检测滚动列是否存在Scatter，Wild, Bonus图标
function ZPLHJMgr:checkSpecialCol(tab)
    local lists = {0,0,0,0,0}
    if(type(tab)~="table") or (tab=={}) then
        return lists
    end    
    for i = 1, colCou, 1 do -- 列
        for j = 1, rowCou, 1 do -- 行
            local v = tab[j][i]+1
            if(v==self.FreeValue)or(v==self.BonusValue)or(v==self.WildValue)  then -- 免费图标
                lists[i]=1
                break
            end
        end
    end
    return lists
end

return ZPLHJMgr