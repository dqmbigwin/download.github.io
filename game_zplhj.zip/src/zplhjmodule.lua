
local GameModule = {}

function GameModule.ReloadScript()
	-- 加载纸牌老虎机场景
	GameModule.reload("game.zplhj.src.zplhjmsg")
	GameModule.reload("game.zplhj.src.zplhjmgr")
	GameModule.reload("game.zplhj.src.zplhjui")
end

function GameModule.reload(md)
	package.loaded[md] = nil
	require(md)
end

return GameModule
